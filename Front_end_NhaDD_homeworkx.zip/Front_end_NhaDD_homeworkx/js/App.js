var App = angular.module('myApp',['ngRoute']);
App.controller('mainCtrl', ['$scope', '$http', function($scope, $http){
	$http.get('api/bike.json').then(function(response) {
   $scope.bikes = response.data.listBike;
   console.log(response.data);
});
}]);

App.config(['$locationProvider','$routeProvider', function($locationProvider,$routeProvider) {
  $locationProvider.hashPrefix('');
    $routeProvider.when("/", {
        templateUrl : "single2.html"
    })
    .when("/single1", {
        templateUrl : "single1.html"
    })
    ;
}]); 
	
